# USAGE
# python final_image.py --image IMG_8552.JPG

# import the necessary packages
from __future__ import print_function
from skimage.feature import peak_local_max
from skimage.morphology import watershed
from scipy import ndimage
import numpy as np
import argparse
import cv2
from sklearn.cross_validation import train_test_split
from sklearn.metrics import classification_report
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from imutils import paths
import numpy as np
import argparse
import mahotas
import pickle as cPickle
import imutils

# construct the argument parse and parse the arguments
ap = argparse.ArgumentParser()
ap.add_argument("-i", "--image", required=True,
	help="path to input image")
args = vars(ap.parse_args())

predict = ""
lis = []
def describe(image):
	# extract the mean and standard deviation from each channel of the image
	# in the HSV color space
	(means, stds) = cv2.meanStdDev(cv2.cvtColor(image, cv2.COLOR_BGR2HSV))
	colorStats = np.concatenate([means, stds]).flatten()

	# extract Haralick texture features
	gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
	haralick = mahotas.features.haralick(gray).mean(axis=0)

	# return a concatenated feature vector of color statistics and Haralick
	# texture features
	return np.hstack([colorStats, haralick])


# load the image and perform pyramid mean shift filtering
# to aid the thresholding step
image = cv2.imread(args["image"])
image = imutils.resize(image, width=500)
#image = cv2.resize(image,(500,600))
shifted = cv2.pyrMeanShiftFiltering(image, 21, 51)
cv2.imshow("Input", image)

clone1 = image.copy()
clone2 = image.copy()

loaded_model = cPickle.load(open("classifier.cPickle", 'rb'))


# convert the mean shift image to grayscale, then apply
# Otsu's thresholding
gray = cv2.cvtColor(shifted, cv2.COLOR_BGR2GRAY)
thresh = cv2.threshold(gray, 0, 255,
	cv2.THRESH_BINARY | cv2.THRESH_OTSU)[1]
cv2.imshow("Thresh", thresh)

# compute the exact Euclidean distance from every binary
# pixel to the nearest zero pixel, then find peaks in this
# distance map
D = ndimage.distance_transform_edt(thresh)
localMax = peak_local_max(D, indices=False, min_distance=100,
	labels=thresh)

# perform a connected component analysis on the local peaks,
# using 8-connectivity, then appy the Watershed algorithm
markers = ndimage.label(localMax, structure=np.ones((3, 3)))[0]
labels = watershed(-D, markers, mask=thresh)
print("[INFO] {} Coins found".format(len(np.unique(labels)) - 1))

one = 0
two = 0
five = 0
ten = 0
value = 0

# loop over the unique labels returned by the Watershed
# algorithm
for label in np.unique(labels):
	# if the label is zero, we are examining the 'background'
	# so simply ignore it
	if label == 0:
		continue

	# otherwise, allocate memory for the label region and draw
	# it on the mask
	mask = np.zeros(gray.shape, dtype="uint8")
	mask[labels == label] = 255

	# detect contours in the mask and grab the largest one
	cnts = cv2.findContours(mask.copy(), cv2.RETR_EXTERNAL,
		cv2.CHAIN_APPROX_SIMPLE)[-2]
	#c = max(cnts, key=cv2.contourArea)


	for c in cnts:
		(x, y, w, h) = cv2.boundingRect(c)
		cv2.rectangle(clone2, (x, y), (x + w, y + h), (0, 255, 0), 2)
		crop = clone1[y:y+h, x:x+w]
		print (w,h)
		features = describe(crop)
		prediction = loaded_model.predict(features.reshape(1, -1))[0]
		#print (prediction)
		lis.append(prediction)
		if (prediction == "1" ):
			one = one+1
		elif (prediction == "2"):
			two = two+1
		elif (prediction == "5"):
			five = five +1
		elif (prediction == "10"):
			ten = ten + 1
		cv2.imshow("out", crop)
		cv2.waitKey(0)

value = one*1 + two*2 + five*5 + ten*10

#print ("Total coin present  ")
print ("ten", ten)
print ("five", five)
print ("two",two)
print ("one",one)

print ("Total Value = ", value)

predict = str(lis)
#print (predict)

value = "Total Value = " + str(value)

predict = "one = " + str(one) +" , "+"two = " + str (two) + " , "+ "five = " + str(five) + " , "+ "ten = " +str(ten)
cv2.putText(clone2, predict, (40,50), cv2.FONT_HERSHEY_SIMPLEX, .50, (0, 255, 0), 1)
cv2.putText(clone2, value, (40,80), cv2.FONT_HERSHEY_SIMPLEX, .50, (0, 255, 0), 1)

# show the output image
cv2.imshow("Output", clone2)
cv2.waitKey(0)