#method to train the chatbot
from chatterbot.trainers import ListTrainer
from chatterbot import ChatBot
import os

bot = ChatBot('Test') # Create the chatbot

bot.set_trainer(ListTrainer)

for fil in os.listdir('files'):
	chats = open ('files\\' + fil, 'r').readlines()
	bot.train(chats)


while True:
	request = input ('You: ')
	response = bot.get_response(request)
	print ('Bot: ', response)